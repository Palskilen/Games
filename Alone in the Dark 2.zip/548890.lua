-- 548890's Lua and Manifest Created by Morrenus
-- Alone in the Dark 2
-- Created: September 28, 2025 at 22:09:52 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 5
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(548890) -- Alone in the Dark 2
addtoken(548890, "16230702072605333904")
-- MAIN APP DEPOTS
addappid(548891, 1, "6634280827b5126301137e580c0599d41549ff96cd8ec7ebf09f946379d11ff2") -- Depot 548891
setManifestid(548891, "4316521633773295034", 578087049)
addappid(548892, 1, "9e429ebe6e5bbf71cc25117e650f6ed055ca650cddf15ca52d281c24afb5bb72") -- Depot 548892
setManifestid(548892, "7466402673672281618", 578086934)
addappid(548893, 1, "e3e46d656931ffd2fa8b6c835fda1c46a478b8d1dc812b8b71a69a84994a4b60") -- Depot 548893
setManifestid(548893, "248985593560467873", 578086955)
addappid(548894, 1, "6d810df61a65a675edd7d64d1b5fa03c2b9dce6191ed2e3638deb21a58559855") -- Depot 548894
setManifestid(548894, "3302015323603764477", 578086934)
addappid(548895, 1, "2b4406c34ae612c96333e4ebfd818197dbe8c04d16521c41cea5e6f57f4cc588") -- Depot 548895
setManifestid(548895, "193952524515284904", 578086955)