-- 21000's Lua and Manifest Created by Morrenus
-- LEGO® Batman™: The Videogame
-- Created: September 29, 2025 at 21:50:23 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 5
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(21000) -- LEGO® Batman™: The Videogame
-- MAIN APP DEPOTS
addappid(21001, 1, "41f749df849f89a6dfccc2ad784a023add7467c5b5222b04ff7b00baae20ac98") -- LEGO Batman Content
setManifestid(21001, "5871323374027822051", 4499488341)
addappid(21002, 1, "63d732c46e22671a3751b82c54652749be5b8d47e4dccb0bd1a1f9e870b4d252") -- LEGO Batman English
setManifestid(21002, "302603787906994898", 149216)
addappid(21003, 1, "6d85ee42b0015812987b32922ef66079a69eb2c25046e6c33533b81e7dbcb43a") -- LEGO Batman French
setManifestid(21003, "4999633951566687241", 214476)
addappid(21004, 1, "86236dcb06a29123ec6d8b5533ae4c271c88335074e225cf027fda1a356d33c7") -- LEGO Batman Spanish
setManifestid(21004, "7397377424455615958", 137969)
addappid(21007, 1, "b6c97168a1cafde4fada8f1503890edf2a324f7b34a8223590b23825a9b9e68a") -- Depot 21007
setManifestid(21007, "6690420575247744391", 7561216)