-- 371970's Lua and Manifest Created by Morrenus
-- Barony
-- Created: September 29, 2025 at 00:09:47 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 5
-- Total DLCs: 3
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(371970, 1, "7ddb00a4dd4ff1611227dd7dc0fa1560d7d533475f5077bd9c5db86e828d887f") -- Barony
-- MAIN APP DEPOTS
addappid(371972, 1, "67e87aa283676e2c78d2a3f8bb8651825e3afd860a0d39da946fbefd252348be") -- Barony Depot (English) (Win32)
setManifestid(371972, "357294808004417833", 935092032)
addappid(371971, 1, "0f85f3847bc67b4d0875d0bee3bde60951129c06cc7aa6a6e2903240d94c3ddb") -- Barony Depot (English) (OSX)
setManifestid(371971, "8797762480074673168", 988118140)
addappid(371973, 1, "2e77491f70fc80a27667adf0df2a1ee28d9ecff8357be343c465f47e62cca248") -- Barony Depot (English) (Linux)
setManifestid(371973, "2869293202979407869", 974157720)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
-- DLCS WITH DEDICATED DEPOTS
-- Barony Extended Soundtrack by Chris Kukla (AppID: 470540)
addappid(470540)
addappid(470540, 1, "04abc82a5fff78401c74b7dc6d2772e9cf3b93f8094dfffc634f9bdbb4bb4b8e") -- Barony Extended Soundtrack by Chris Kukla - Barony Extended Soundtrack by Chris Kukla (470540) Depot
setManifestid(470540, "8637528418297383130", 328190002)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1010820) -- Barony Myths  Outcasts DLC Pack 1
addappid(1010821) -- Barony Legends  Pariahs DLC Pack 2