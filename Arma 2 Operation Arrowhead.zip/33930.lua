-- 33930's Lua and Manifest Created by Morrenus
-- Arma 2: Operation Arrowhead
-- Created: September 28, 2025 at 23:02:36 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 4

-- MAIN APPLICATION
addappid(33930) -- Arma 2: Operation Arrowhead
-- MAIN APP DEPOTS
addappid(33931, 1, "3b324ca60026d263ac2c391af625442d40c7675e5f1894a9e340c0c435d1499e") -- arma 2 operation arrowhead content
setManifestid(33931, "7739883071566525791", 8714127071)
addappid(33937, 1, "309019a4078b23b7d63eb7869152b006789ba736c1badd1eeb6be1773d86c04c") -- A2: OA RFT Fix Depot
setManifestid(33937, "6080133772376467329", 9491)
-- DLCS WITH DEDICATED DEPOTS
-- Arma 2 Army of the Czech Republic DLC (AppID: 33934)
addappid(33934)
addappid(33934, 1, "e76a2c7fff33e0185e60063b7dadb06d7ecbac7eb586b3cf54bdbbd387afed56") -- Arma 2 Army of the Czech Republic DLC - ARMA 2 ACR depot
setManifestid(33934, "1218581768977878334", 1472611829)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(33933) -- ARMA 2 Army of the Czech Republic - OLD APPID
addappid(33936) -- ValveTestApp33936
addappid(33960) -- ARMA II British Armed Forces