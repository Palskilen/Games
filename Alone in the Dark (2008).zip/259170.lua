-- 259170's Lua and Manifest Created by Morrenus
-- Alone in the Dark (2008)
-- Created: September 28, 2025 at 22:09:44 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(259170) -- Alone in the Dark (2008)
-- MAIN APP DEPOTS
addappid(259171, 1, "36a625c3c671f93e981314833d0250232a6ff453cd9f7f626e94425c2f7f731a") -- Alone in the Dark Content
setManifestid(259171, "2952440167262994037", 8123596736)
-- SHARED DEPOTS (from other apps)
addappid(228981, 1, "9afdbd47677424be993f6b516a15ebdb5281aa318114631d14b2b23999ae97ac") -- VC 2005 Redist (Shared from App 228980)
setManifestid(228981, "7613356809904826842", 5884085)