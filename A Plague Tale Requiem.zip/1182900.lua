-- 1182900's Lua and Manifest Created by Morrenus
-- A Plague Tale: Requiem
-- Created: September 30, 2025 at 17:35:09 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 1
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1182900) -- A Plague Tale: Requiem
-- MAIN APP DEPOTS
addappid(1182901, 1, "89056a553dcf6ee12c8c1a92b728c89e8457fb95ec117f931d7115aa918cbd18") -- Depot 1182901
setManifestid(1182901, "3367036266289852265", 53070236837)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1906530) -- A Plague Tale Requiem - Protector Pack