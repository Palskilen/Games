-- 33900's Lua and Manifest Created by Morrenus
-- Arma 2
-- Created: September 28, 2025 at 23:02:26 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(33900) -- Arma 2
-- MAIN APP DEPOTS
addappid(33902, 1, "d38d4094b44356928935645d092118615ea6bdd2d833474c272cc64cd5a4853e") -- ARMA II us exe
setManifestid(33902, "5881538059138944576", 11263112)
addappid(33904, 1, "ecdc75cdb4173caa93b8847601363c1ff3a2d65392118acce45aeafe4e45aa61") -- Arma 2 BETA Depot 2
setManifestid(33904, "9124136800091614874", 195746622)
addappid(33901, 1, "c07cec672c1aa48a1493532ec6a9e04a5f351ce1d1445f8eb98ba8c93ff5fa27") -- arma 2 content
setManifestid(33901, "357000457446013132", 8939751577)