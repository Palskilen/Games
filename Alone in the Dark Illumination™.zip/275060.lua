-- 275060's Lua and Manifest Created by Morrenus
-- Alone in the Dark: Illumination
-- Created: September 28, 2025 at 22:10:04 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(275060) -- Alone in the Dark: Illumination
-- MAIN APP DEPOTS
addappid(275062, 1, "5fc3cdbfd9725c25061a073ca8a00c20ebcb6949288a87a24e96957e701784a0") -- Alone in the Dark: Illumination
setManifestid(275062, "3726797217969217820", 14031574802)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(330040) -- Alone in the Dark Illumination - Eldritch Edition