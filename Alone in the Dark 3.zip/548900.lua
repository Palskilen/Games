-- 548900's Lua and Manifest Created by Morrenus
-- Alone in the Dark 3
-- Created: September 28, 2025 at 22:09:46 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(548900) -- Alone in the Dark 3
addtoken(548900, "9740243587769436864")
-- MAIN APP DEPOTS
addappid(548901, 1, "7477b7b9fea221aa3d9275eec90e545c2cff335e90e0c223f12a417204f8eddc") -- Depot 548901
setManifestid(548901, "3144837604879153231", 152301062)
addappid(548902, 1, "8a473741d7f7fbd4401ee3a701d86b1fdb4bad6d10cdcc484c3efd5a3529b80d") -- Depot 548902
setManifestid(548902, "6970708639305648039", 151753120)
addappid(548903, 1, "86218f5c4a50fbdf2a5cb40e6ec5c5b09ccb21d620438e715a89b8c09f894e44") -- Depot 548903
setManifestid(548903, "3037489625228852350", 152619117)
addappid(548904, 1, "5cf9f55f486f1dd7b3f12b6d74d3c68cd8281e4ca609a37634c60a1cc21e1efa") -- Depot 548904
setManifestid(548904, "2140371123782509770", 154163282)