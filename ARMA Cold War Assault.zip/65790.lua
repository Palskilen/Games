-- 65790's Lua and Manifest Created by Morrenus
-- Arma: Cold War Assault
-- Created: September 28, 2025 at 23:04:09 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(65790) -- Arma: Cold War Assault
-- MAIN APP DEPOTS
addappid(65791, 1, "4875303350f459c37a78d1edc36d9de1dd33f0bf39c8fd5f67f392c2e7eedc1a") -- ARMA Cold War Assault depot
setManifestid(65791, "3308406618218950580", 805520989)