-- 1017900's Lua and Manifest Created by Morrenus
-- Age of Empires: Definitive Edition
-- Created: September 28, 2025 at 21:43:18 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1017900) -- Age of Empires: Definitive Edition
-- MAIN APP DEPOTS
addappid(1017901, 1, "d28682965acebec2e120b391343fe1f369835501696e82b33a6312037eb0b0d5") -- Darwin Content
setManifestid(1017901, "410572971259215218", 12933537838)
-- SHARED DEPOTS (from other apps)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)