-- 2692990's Lua and Manifest Created by Morrenus
-- DON'T SCREAM TOGETHER
-- Created: December 15, 2025 at 15:34:16 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(2692990) -- DON'T SCREAM TOGETHER
-- MAIN APP DEPOTS
addappid(2692991, 1, "9b971dfb6dc8c67c3cd15d90b0daf3432bca02a2816476c9d877630216b0ec9a") -- Depot 2692991
setManifestid(2692991, "2032568899701963846", 14846716198)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)