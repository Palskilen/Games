-- 213330's Lua and Manifest Created by Morrenus
-- LEGO® Batman™ 2: DC Super Heroes
-- Created: September 29, 2025 at 21:50:06 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(213330) -- LEGO® Batman™ 2: DC Super Heroes
-- MAIN APP DEPOTS
addappid(213331, 1, "03976d814e897ba3149d20c91a0e7632e6af023515843587f4c87735858083b6") -- LEGO Batman 2 Content
setManifestid(213331, "8278681763622938386", 4082057609)
addappid(213333, 1, "423701c3a5d4c131e6f2e0edbd0374b6920bb8bf8da058b8dc80ab4d1432c6c5") -- Depot 213333
setManifestid(213333, "3563482172676595656", 4127312)
addappid(213332, 1, "8e5378ba5b4acd1be7ab0484e9e2bcd28badab5e8583fa07a01f253103d1c2d7") -- Depot 213332
setManifestid(213332, "3876198923344511345", 4127312)