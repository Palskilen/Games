-- 210550's Lua and Manifest Created by Morrenus
-- Angry Birds Space
-- Created: September 28, 2025 at 22:31:06 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(210550) -- Angry Birds Space
-- MAIN APP DEPOTS
addappid(210551, 1, "7bf50929c3097fb087324de3c9d71f14e4b7d84acd0b711be35d0732e925a781") -- Angry Birds Space Content
setManifestid(210551, "7755649356718600135", 139761902)