-- 444640's Lua and Manifest Created by Morrenus
-- Bloons TD Battles
-- Created: October 18, 2025 at 20:36:48 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 5
-- Total DLCs: 1
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(444640) -- Bloons TD Battles
-- MAIN APP DEPOTS
addappid(444641, 1, "059a521905bc834d23ee775fc43e5e3b6d78e91b4e7183f00219b874782ddcba") -- Battles Win
setManifestid(444641, "6187719522943592914", 103473467)
addappid(444642, 1, "57f5cf626c8a448af5894b2fc626ea958ecc5ec3dfd2e3c1677a0dcd471b3df3") -- Battles OSX
setManifestid(444642, "6162099541481128393", 95293630)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(472350) -- Bloons TD Battles - Club Starter Pack