-- 1276390's Lua and Manifest Created by Morrenus
-- Bloons TD Battles 2
-- Created: November 29, 2025 at 11:02:28 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1276390, 1, "5f493536ada36b094df85a1cae7ea625bf96c7e6864d5e2bfc7f35a249c538b9") -- Bloons TD Battles 2
-- MAIN APP DEPOTS
addappid(1276391, 1, "3906c873bfc5a0974c59a35dd0a92eb215158ebd43fe686cc7253ff7037e6dde") -- Bloons TD Battles 2 Win
setManifestid(1276391, "7014429438865563306", 895929422)
addappid(1276392, 1, "3f29749f5600a4d14e4005553ee833ebc94be009b2e10a4884044c570ff9d117") -- Bloons TD Battles 2 OSX
setManifestid(1276392, "5531275274587155349", 865580785)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)