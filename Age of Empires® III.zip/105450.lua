-- 105450's Lua and Manifest Created by Morrenus
-- Age of Empires® III (2007)
-- Created: September 28, 2025 at 21:43:22 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 6
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(105450) -- Age of Empires® III (2007)
-- MAIN APP DEPOTS
addappid(105451, 1, "373b9d35f75b5cd3868a9e60b5cd1c52d227932c2e53fa4b8f0adea46df12da8") -- Age of Empires® III: Complete Collection
setManifestid(105451, "1467620138955498058", 4023656915)
addappid(105452, 1, "a895c74a9ffcf83407de5a2a7a0a4bbdd56edcc850028ea9d84ecd4d3057d594") -- Age of Empires® III: Complete Collection EN
setManifestid(105452, "2342005950339938519", 1484220530)
addappid(105453, 1, "be9bb714cb1a0debed818018dc42d1748c9a2274887ea57f07d339a46d5bbb35") -- Age of Empires® III: Complete Collection FR
setManifestid(105453, "1967925846238743194", 1370068622)
addappid(105454, 1, "bcb76b7fe8cbbdf935fa741824d8b30fdfc473c4ee7a813a92f93f6e94c6c73f") -- Age of Empires® III: Complete Collection ES
setManifestid(105454, "1790565567410048633", 1431062315)
addappid(105455, 1, "629730fd5c00b555d72ef9c37139ca503a019bb49108a51f57f6ec74557c0297") -- Age of Empires® III: Complete Collection IT
setManifestid(105455, "4505451071533775742", 1451695581)
addappid(105456, 1, "7bd306d9ba0b5efae8567b789047d8a6f5848a021e4dd95701fa504a8649b8f9") -- Age of Empires® III: Complete Collection DE
setManifestid(105456, "3188610332404126005", 1433428014)