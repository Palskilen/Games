-- 1808500's Lua and Manifest Created by Morrenus
-- ARC Raiders
-- Created: December 18, 2025 at 06:15:09 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 4
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1808500) -- ARC Raiders
-- MAIN APP DEPOTS
addappid(1808501, 1, "9f7c91d4609594120c713e82bb64d0ebf15c63fdf6887bc2b3f8f20fcf58e005") -- Depot 1808501
setManifestid(1808501, "1601082507973459143", 40545080174)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(3948500) -- ARC Raiders - The Astro Bundle (Pre-Order Exclusive)
addappid(3948510) -- ARC Raiders - Upgrade to Deluxe Edition
addappid(4048380) -- ARC Raiders - Standard Edition Bonus (Pre-Order Exclusive)
addappid(4210150) -- ARC Raiders - The Bonecrown Set