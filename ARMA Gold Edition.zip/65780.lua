-- 65780's Lua and Manifest Created by Morrenus
-- Arma: Gold Edition
-- Created: September 28, 2025 at 23:04:28 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(65780) -- Arma: Gold Edition
-- MAIN APP DEPOTS
addappid(65781, 1, "847f8fee18b674905052ad492e0269c17993b2271d434cd2c33d7880ab2ea1cc") -- ARMA Gold depot
setManifestid(65781, "1749253253702512236", 6805080887)