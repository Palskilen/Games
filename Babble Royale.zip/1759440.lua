-- 1759440's Lua and Manifest Created by Morrenus
-- Babble Royale
-- Created: September 28, 2025 at 23:49:27 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1759440) -- Babble Royale
-- MAIN APP DEPOTS
addappid(1759441, 1, "ad18e1e755866eaad0b0849f590a1ced92d515799d67569dce98f6b4bd13ee0d") -- Babble Royale Content
setManifestid(1759441, "3686070250805319848", 754523924)
addappid(1759442, 1, "cea58b2c5c7744cd161d1acd645a9672768f576a1d29ed98dbd265f74022ccf2") -- Babble Royale OSX Depot
setManifestid(1759442, "5238581154265747887", 749414881)