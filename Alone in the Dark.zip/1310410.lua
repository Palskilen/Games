-- 1310410's Lua and Manifest Created by Morrenus
-- Alone in the Dark
-- Created: September 28, 2025 at 22:09:36 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 7
-- Total DLCs: 4
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(1310410) -- Alone in the Dark
-- MAIN APP DEPOTS
addappid(1310411, 1, "2d39fddfd2e106911e6b2163a3bad7f70ba00af107fe1e777f8768c28d16205a") -- Depot 1310411
setManifestid(1310411, "1599423929991799385", 31651099023)
-- SHARED DEPOTS (from other apps)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITH DEDICATED DEPOTS
-- Alone in the Dark - Vintage Horror Filter Pack (AppID: 2450980)
addappid(2450980)
addappid(2450980, 1, "830385766c9907cd940ae7ed43a699dc2a0b711e2ee4010cb7ee2266083b7980") -- Alone in the Dark - Vintage Horror Filter Pack - Depot 2450980
setManifestid(2450980, "4188049365323835729", 0)
-- Alone in the Dark - Derceto 1992 Costume Pack (AppID: 2450981)
addappid(2450981)
addappid(2450981, 1, "4727b48ab9d30b5fb95ce96910bfcae1e51964b4415eabbb4d129b15497c77dd") -- Alone in the Dark - Derceto 1992 Costume Pack - Depot 2450981
setManifestid(2450981, "4074926775292582049", 0)
-- Alone in the Dark - Directors Commentary Mode (AppID: 2450982)
addappid(2450982)
addappid(2450982, 1, "863e33498a4c3aeb954f799e797789e5964aa5f8072d77236637bd57c4d914ab") -- Alone in the Dark - Directors Commentary Mode - Depot 2450982
setManifestid(2450982, "3337194034610531235", 0)
-- Alone in the Dark - Digital Artbook (AppID: 2450983)
addappid(2450983)
addappid(2450983, 1, "1e3b4a0692e673e1db221cd86f537a88bff72856f78a90ab2f7b8eb1021c401d") -- Alone in the Dark - Digital Artbook - Depot 2450983
setManifestid(2450983, "6929282419867829082", 20652202)