-- 548090's Lua and Manifest Created by Morrenus
-- Alone in the Dark 1
-- Created: September 28, 2025 at 22:09:49 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(548090) -- Alone in the Dark 1
addtoken(548090, "2917647076834286748")
-- MAIN APP DEPOTS
addappid(548091, 1, "b5fc0aaae206fb171ea9a3db549a038ca5a69c2e3ad2cc36c923a45b8a5b605e") -- Depot 548091
setManifestid(548091, "6756926495438634316", 390407897)