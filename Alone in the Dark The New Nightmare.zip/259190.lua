-- 259190's Lua and Manifest Created by Morrenus
-- Alone in the Dark: The New Nightmare
-- Created: September 28, 2025 at 22:10:00 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(259190) -- Alone in the Dark: The New Nightmare
-- MAIN APP DEPOTS
addappid(259191, 1, "2e5aef10fe649f7ddeeabcc8dac60977bd4f8c43fd4b0bf88845418dbccb25d4") -- Alone in the Dark: The New Nightmare Content
setManifestid(259191, "6102496235202809740", 1533115592)