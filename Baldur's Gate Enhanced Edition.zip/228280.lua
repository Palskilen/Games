-- 228280's Lua and Manifest Created by Morrenus
-- Baldur's Gate: Enhanced Edition
-- Created: September 29, 2025 at 00:00:58 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 9
-- Total DLCs: 3
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(228280, 1, "4e0b2a31f4ddfbacaad8a5461b1b9f2301368ca6d7ce4692e94a552e7c97a0a1") -- Baldur's Gate: Enhanced Edition
-- MAIN APP DEPOTS
addappid(228281, 1, "4ccf8f28b07eacbfb0320da73abf7788fc518b7033c62add7d18f78ca3515d41") -- Baldur's Gate: Enhanced Edition Content
setManifestid(228281, "4786611430036960238", 8197432)
addappid(228282, 1, "9cdf4cfa2a2094c6d1185d0a9af745b5a756009379807dbc6fd0f67e66f7021c") -- Baldur's Gate: Enhanced Edition for Mac OS
setManifestid(228282, "3938075005126076261", 17592168)
addappid(228283, 1, "4f7ed9dcac7787ecaa8afed35c4c507395a02729b94ff10e4a714ba32c769774") -- Baldur's Gate: Enhanced Edition for Linux
setManifestid(228283, "2843984763890365440", 13392570)
addappid(228284, 1, "0abb087e1849124c069599acf1c23799f2c092ad60715192a499686d3274c07c") -- Baldur's Gate: Enhanced Edition Game Data
setManifestid(228284, "4789446795241284727", 3327758834)
-- SHARED DEPOTS (from other apps)
addappid(228982, 1, "fa2997f03c3576c41174f200596ab2246fd1e39c0911f9b869e92635ae5b0ff5") -- VC 2008 Redist (Shared from App 228980)
setManifestid(228982, "6413394087650432851", 9688647)
addappid(229020, 1, "efca2304d92ac2bb7ebca174e6e5015fb0daf45d7db8ecfc1db6eaccdc7b27d9") -- OpenAL 2.0.7.0 Redist (Shared from App 228980)
setManifestid(229020, "5799761707845834510", 810085)
-- DLCS WITH DEDICATED DEPOTS
-- Baldurs Gate Siege of Dragonspear (AppID: 385970)
addappid(385970)
addappid(385970, 1, "bf55252acfbe28dd4bdb5a7ae0ca72062da2ec4f25f1ec98de97dd462711437a") -- Baldurs Gate Siege of Dragonspear - Baldur's Gate: Siege of Dragonspear (385970) Depot
setManifestid(385970, "6988769666681604628", 1931414699)
-- Baldurs Gate Faces of Good and Evil (AppID: 687500)
addappid(687500)
addappid(687500, 1, "6d9e2461ecf9c235d6dfcce8611dba21cdcc9161d7bc8c2ef4c08caa67ff9a14") -- Baldurs Gate Faces of Good and Evil - Faces of Good and Evil (687500) Depot
setManifestid(687500, "863991843391206910", 1252307)
-- Baldurs Gate Reflections Of Myth  Valor (AppID: 2488970)
addappid(2488970)
addappid(2488970, 1, "eb868fb93e0936f72260320071124dcf050e11fdaefcc2aee9919b6787bc133b") -- Baldurs Gate Reflections Of Myth  Valor - Depot 2488970
setManifestid(2488970, "6576850693656477116", 5501443)