-- 208650's Lua and Manifest Created by Morrenus
-- Batman™: Arkham Knight
-- Created: September 29, 2025 at 00:14:00 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 49
-- Total DLCs: 35
-- Shared Depots: 4

-- MAIN APPLICATION
addappid(208650) -- Batman™: Arkham Knight
-- MAIN APP DEPOTS
addappid(208651, 1, "8a97d85dcbfa7bcfada811d3d52ae29b76a944b631699c289aa75e4a00cada01") -- Batman™: Arkham Knight Depot
setManifestid(208651, "6853321344171268435", 57921206895)
addappid(208657, 1, "ab40f1d726829a529be64ba75b8e418c3dbed7465cf9c258ce6ccfa0f8683eb3") -- Batman™: Arkham Knight Japanese Depot
setManifestid(208657, "3694940299621196857", 1989797535)
addappid(208652, 1, "ad3e532ecd7d658a22f023888c8c9ded091d97554b6475673133d5c30ab860ce") -- Batman™: Arkham Knight Depot French
setManifestid(208652, "3450399033030215251", 1944683839)
addappid(208653, 1, "03933044978c8e77418c1237f060f5cb5b6f87cd764f56fc43914b6ca25715f7") -- Batman™: Arkham Knight Depot Italian
setManifestid(208653, "8852253870666083362", 2071189401)
addappid(208654, 1, "68d6dcbadaab99cf7572ed6f30f70d8fc33c6942715a2051db7eecc715ce3661") -- Batman™: Arkham Knight Depot German
setManifestid(208654, "2674452793258892992", 2031178069)
addappid(208655, 1, "7a6a23728e89c662d82fc8f821afa4c1129983d6170de7cf556f53bb2a3540fb") -- Batman™: Arkham Knight Depot Spanish
setManifestid(208655, "6613395593763429745", 4278129942)
addappid(208656, 1, "7846bdd030dd34f005d5b92d76d06042f386784982a2bc361435cd9b3b2d15da") -- Batman™: Arkham Knight Depot Portuguese (Brazil)
setManifestid(208656, "9016234191343016049", 2030720787)
addappid(208658, 1, "3efc43f1da352f7db902fbc686e856422e0b33d76955229b74f493cee344e52f") -- Batman™: Arkham Knight Depot Polish
setManifestid(208658, "5079279402124339390", 1487851)
addappid(208659, 1, "0630c5f38120cd92b34b10ce80d8c4db6b3800fd0dcac249f6a9046aaf6b6ab5") -- Batman™: Arkham Knight Depot Russian
setManifestid(208659, "3534775638330471183", 1446075)
addappid(208660, 1, "60e255b632df87e4b684c2c2bb59192183228df45501b36cd656c25a3da4c8ea") -- Batman™: Arkham Knight Depot Korean
setManifestid(208660, "3004825579129987438", 988837)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)
-- DLCS WITH DEDICATED DEPOTS
-- Harley Quinn Story Pack (AppID: 313100)
addappid(313100)
addtoken(313100, "6653730490579503997")
addappid(313100, 1, "f9b98a8593a0a5c2781af684b2a2faf16b572eb0fb352bcf982b77264dab5901") -- Harley Quinn Story Pack - Harley Quinn Story Pack (313100) Depot
setManifestid(313100, "8110651229437568001", 1195214788)
-- Red Hood Story Pack (AppID: 313101)
addappid(313101)
addtoken(313101, "15314208610850822235")
addappid(313101, 1, "d9f03fa21ace7e05db14d912a01f4c5a0ff7233eff1d9c477f23e4ef60f1f412") -- Red Hood Story Pack - GS Exclusive Story Pack (313101) Depot
setManifestid(313101, "7262992429664724640", 940402242)
-- A Matter of Family (AppID: 313102)
addappid(313102)
addtoken(313102, "1363214241405776750")
addappid(313102, 1, "dcc0962525c06de3012e0eea1056578154409cac352d4091dccc038ab20ec7c0") -- A Matter of Family - D45 DLC Drop (313102) Depot
setManifestid(313102, "5290306600308231632", 3451946774)
-- Batman Arkham Knight - WayneTech Booster Pack (AppID: 350170)
addappid(350170)
addtoken(350170, "2846027695980888523")
addappid(350170, 1, "e63920d41fb19546e17aab7d86942350f318c4fbb9f99d189a35b305994eb9a8") -- Batman Arkham Knight - WayneTech Booster Pack - Cougar (350170) Depot
setManifestid(350170, "5484906920703570221", 673)
-- Prototype Batmobile Skin (AppID: 350171)
addappid(350171)
addtoken(350171, "14032330326300423447")
addappid(350171, 1, "2b9bccd9ab3214d553070e15d5fb4a5ebac59b3dda479b3f9388ad3484069411") -- Prototype Batmobile Skin - Dingo (350171) Depot
setManifestid(350171, "3987672753345161973", 166218202)
-- Batman Classic TV Series Batmobile Pack (AppID: 350172)
addappid(350172)
addtoken(350172, "15766568935433533440")
addappid(350172, 1, "72f9a079b607c14179c73013bc62d8c12d6d97b4ffed005e477c0e7e54396025") -- Batman Classic TV Series Batmobile Pack - Elephant (350172) Depot
setManifestid(350172, "3497203559893359373", 862914077)
-- Batman 1st Appearance Skin (AppID: 356470)
addappid(356470)
addtoken(356470, "5437820700632039034")
addappid(356470, 1, "c71fb5ddc69bfe2922f7a0091f5ce05c6437daa17cfa0d3ebb8f65e3f2bb1d2d") -- Batman 1st Appearance Skin - Giraffe (356470) Depot
setManifestid(356470, "5626179739413771033", 45564653)
-- Batman Flashpoint Skin (AppID: 356471)
addappid(356471)
addtoken(356471, "17948550361057423907")
addappid(356471, 1, "1ef700fc08b4e9c6aa8f4244a32bf02c04d35a939c5f789584bdeeb8ed6f7143") -- Batman Flashpoint Skin - Hamster (356471) Depot
setManifestid(356471, "2478834768825952397", 56258643)
-- Batman Inc. Skin (AppID: 356472)
addappid(356472)
addtoken(356472, "12839632296456182009")
addappid(356472, 1, "e81466ad1fadea859c76f61386741d6f7c71db8b78c34d4c08ca413a84e4f036") -- Batman Inc. Skin - Iguana (356472) Depot
setManifestid(356472, "4938222717222655398", 54541292)
-- Batman Noel Skin (AppID: 356473)
addappid(356473)
addtoken(356473, "6100168057934959206")
addappid(356473, 1, "96a6572abd9dd230a076b85357f6eef83b231d5e23da796b06d0f0579ec21ffc") -- Batman Noel Skin - Jackal (356473) Depot
setManifestid(356473, "3712656317042219860", 48167238)
-- Batman Arkham Knight - New 52 Skins Pack (AppID: 356474)
addappid(356474)
addtoken(356474, "10299780190695911333")
addappid(356474, 1, "ff69c44da5f957be17ec9ded27fd1155299a9e1977b95282066a2125b007d094") -- Batman Arkham Knight - New 52 Skins Pack - Kangaroo (356474) Depot
setManifestid(356474, "6677439078887775389", 118356573)
-- Gothams Future Skin Pack (AppID: 356620)
addappid(356620)
addtoken(356620, "16626451261399906160")
addappid(356620, 1, "13062ecf57cbcde8515a2c5324f79d47863021ba77ec872aa47f19748a84d576") -- Gothams Future Skin Pack - Lemur (356620) Depot
setManifestid(356620, "5788105220867192985", 130776678)
-- Batman Arkham Knight - Season Pass (AppID: 367480)
addappid(367480)
addappid(367480, 1, "e9e200b6947cc4c70a8c34ec795d98cac2780b82f50d38eef03f49011fe81eca") -- Batman Arkham Knight - Season Pass - Batman Arkham Knight Season Pass (367480) Depot
setManifestid(367480, "3606756076691948072", 214)
-- Bat-Family Skin Pack (AppID: 401620)
addappid(401620)
addtoken(401620, "1751646304290189974")
addappid(401620, 1, "1dcb32fc9efed60422a76493dcafb869b85d3acf36822768de5bb1061b8cfd72") -- Bat-Family Skin Pack - [RST] Skins 1 (401620) Depot
setManifestid(401620, "5650775622425268529", 250112659)
-- 1989 Movie Batmobile Pack (AppID: 401621)
addappid(401621)
addtoken(401621, "9027608409892986819")
addappid(401621, 1, "cdb35c09b865afbc396d27a0d54aa61a0ea95cd5ff7640230b453c403beb1fc2") -- 1989 Movie Batmobile Pack - [RST] Baboon (401621) Depot
setManifestid(401621, "7231896095471862909", 819552926)
-- Crime Fighter Challenge Pack 1 (AppID: 401622)
addappid(401622)
addtoken(401622, "2260924484077213391")
addappid(401622, 1, "bc6e84f42fc33b604fd379ec7d456fdc7ca3d816212fabe789ce963b20ce5319") -- Crime Fighter Challenge Pack 1 - [RST] CP1 (401622) Depot
setManifestid(401622, "1545497672192607809", 83701675)
-- Crime Fighter Challenge Pack 2 (AppID: 401623)
addappid(401623)
addtoken(401623, "13881240232871075917")
addappid(401623, 1, "8834bd8ca63b79e49b83bb2859edbad44d7464b25523df8f0a8ed54b9e241f46") -- Crime Fighter Challenge Pack 2 - [RST] CP2 (401623) Depot
setManifestid(401623, "8147537144867843257", 109805965)
-- Crime Fighter Challenge Pack 3 (AppID: 401624)
addappid(401624)
addtoken(401624, "18333713909868684140")
addappid(401624, 1, "e13274658eaedaf8c1f979d615776a264b3fe384f874502409faed790424ddbf") -- Crime Fighter Challenge Pack 3 - [RST] CP3 (401624) Depot
setManifestid(401624, "520242654755417680", 292707377)
-- Crime Fighter Challenge Pack 4 (AppID: 401625)
addappid(401625)
addtoken(401625, "17106024703463478980")
addappid(401625, 1, "42ff34cc3d35cb5543f940ae7961aaa88679e4e54fc40214908e5689a1d4daaa") -- Crime Fighter Challenge Pack 4 - [RST] CP4 (401625) Depot
setManifestid(401625, "2710630062139500645", 146037113)
-- Crime Fighter Challenge Pack 5 (AppID: 401626)
addappid(401626)
addappid(401626, 1, "d2cafda849a6e5bca68ee1d934bc061583c018f6497459b08e0b5b9b7571a179") -- Crime Fighter Challenge Pack 5 - [RST] CP5 (401626) Depot
setManifestid(401626, "4849913725854640808", 502818130)
-- Batman Arkham Knight - Original Arkham Batman Skin (AppID: 401627)
addappid(401627)
addtoken(401627, "14647228768834347985")
addappid(401627, 1, "9a44a42553f09a2ae706abab0890620d0304ca2e45e113b342cda41645937f80") -- Batman Arkham Knight - Original Arkham Batman Skin - [RST] Skin Anteater (401627) Depot
setManifestid(401627, "775693187063658849", 19749989)
-- GCPD Lockdown (AppID: 401628)
addappid(401628)
addtoken(401628, "17079082316492371223")
addappid(401628, 1, "68b22fcfa069b46093cd6aecf639924762cff32b2224cdf7eea594a87cadf896") -- GCPD Lockdown - [RST] Nightingale (401628) Depot
setManifestid(401628, "2107847684480217078", 1037989707)
-- 2008 Tumbler Batmobile Pack (AppID: 401629)
addappid(401629)
addtoken(401629, "12603338808026809910")
addappid(401629, 1, "7470b3540116cccb12cbb6cffc3480720da9ace63e66588af956c68114750f3e") -- 2008 Tumbler Batmobile Pack - [RST] Tiger (401629) Depot
setManifestid(401629, "4842392268768366952", 652896795)
-- Catwomans Revenge (AppID: 401630)
addappid(401630)
addtoken(401630, "4220638834764226062")
addappid(401630, 1, "37300f2f9b6434fe537ac42da78757515cfc58fb73123ab0ec0940d3530f8811") -- Catwomans Revenge - [RST] Caterpillar (401630) Depot
setManifestid(401630, "4484371311303933478", 819452025)
-- Robin and Batmobile Skins Pack (AppID: 401631)
addappid(401631)
addtoken(401631, "16670329159277791729")
addappid(401631, 1, "290d938ef01a4ea9a30eb1dff209ebfe9140bc50cf685b6d67c88e3494f1a3b8") -- Robin and Batmobile Skins Pack - [RST] Skin Rabbit (401631) Depot
setManifestid(401631, "8645674641582132876", 82070931)
-- WayneTech Track Pack (AppID: 401632)
addappid(401632)
addtoken(401632, "9886254994946403695")
addappid(401632, 1, "1b60b263c00fb854946272b5aa86b049e947646d3d020bcd5fe8a7d248ef7ba7") -- WayneTech Track Pack - [RST] Walrus (401632) Depot
setManifestid(401632, "1162530792470177130", 566443974)
-- A Flip of a Coin (AppID: 401633)
addappid(401633)
addtoken(401633, "11769075000650575961")
addappid(401633, 1, "56df97195d9b735009d23bb077f16e871514e486e5047e4b0f46aebaaed83df2") -- A Flip of a Coin - [RST] Termite (401633) Depot
setManifestid(401633, "2721047749624962488", 820374893)
-- 2016 Batman v Superman Batmobile Pack (AppID: 401634)
addappid(401634)
addtoken(401634, "2130655645994826439")
addappid(401634, 1, "6744b02ff1b8870ed01ed085e93191dbd9812be5fc565e51346f7c443bbace60") -- 2016 Batman v Superman Batmobile Pack - [RST] Scorpion (401634) Depot
setManifestid(401634, "8945194768592260894", 343763210)
-- Season of Infamy Most Wanted Expansion (AppID: 401635)
addappid(401635)
addappid(401635, 1, "b6e7c62c20586041796a770d2cb03eeb070ceaf9c2093502fbc297e74b922540") -- Season of Infamy Most Wanted Expansion - [RST] Rhino (401635) Depot
setManifestid(401635, "3719816048852478022", 3976930915)
-- 1970s Batman Themed Batmobile Skin (AppID: 405030)
addappid(405030)
addtoken(405030, "5209508164054038170")
addappid(405030, 1, "38abd1d23bfb6524e794105a628037ff27119b8ccd252de41c2b5e5295c14a19") -- 1970s Batman Themed Batmobile Skin - [RST] Cow (405030) Depot
setManifestid(405030, "8730168787706645695", 42662220)
-- Riddler Themed Batmobile Skin (AppID: 405031)
addappid(405031)
addtoken(405031, "17155148804481485994")
addappid(405031, 1, "2a9528498581c30a68827245d8a6ba3dbf787129c2004505c3a97a7f46b6fe3d") -- Riddler Themed Batmobile Skin - [RST] Rat (405031) Depot
setManifestid(405031, "8255476675879225051", 44659255)
-- Original Arkham Batmobile (AppID: 405032)
addappid(405032)
addappid(405032, 1, "27f7cc903cdc5d3cccc3cdfc3502b6b036941eb0262a30973f1d01aa0b713fe3") -- Original Arkham Batmobile - [RST] Alligator (405032) Depot
setManifestid(405032, "9038982586665794910", 58028593)
-- Rocksteady Themed Batmobile Skin (AppID: 405033)
addappid(405033)
addtoken(405033, "9463777417809417307")
addappid(405033, 1, "007aaab7fc87bd60c5b7a1a2eef65c85a111f48675213b0815e56a99e8516e43") -- Rocksteady Themed Batmobile Skin - [RST] Raccoon (405033) Depot
setManifestid(405033, "1986676591940919202", 40436795)
-- Crime Fighter Challenge Pack 6 (AppID: 415650)
addappid(415650)
addtoken(415650, "9467990814504622550")
addappid(415650, 1, "278a2aa5ea030e5d6d40aaa1b21a7c8b0522cd516b746d36001bb0b3c53c3aba") -- Crime Fighter Challenge Pack 6 - [RST] CP6 (415650) Depot
setManifestid(415650, "2894776399321303562", 711337847)
-- 2008 Movie Batman Skin (AppID: 418930)
addappid(418930)
addtoken(418930, "7313729839811237955")
addappid(418930, 1, "939a6ac2246b15c32800a6146e923753cd17015ad2b2f017d4069a682fc44be3") -- 2008 Movie Batman Skin - [RST] DK (418930) Depot
setManifestid(418930, "907962518235742652", 61914494)