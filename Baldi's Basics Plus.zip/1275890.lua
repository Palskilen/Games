-- 1275890's Lua and Manifest Created by Morrenus
-- Baldi's Basics Plus
-- Created: November 12, 2025 at 08:19:51 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(1275890) -- Baldi's Basics Plus
-- MAIN APP DEPOTS
addappid(1275891, 1, "311496f62a59013629f9698b66e74dc8432a2fd9d30b1182891b7a37a9f2113f") -- Baldi's Basics Plus Windows
setManifestid(1275891, "8390830667697165317", 935012688)
addappid(1275892, 1, "1e23c689edc58019b16cb8dbd4a58a337349ea18d0a52dc77b2882ad0c4dd3e4") -- Baldi's Basics Plus Linux
setManifestid(1275892, "70563334917583563", 977673226)
addappid(1275893, 1, "cdd2e002910dcea162209fe5a2b76a05dd46856d6a4b649e09b7b8ccf7ccc1e8") -- Baldi's Basics Plus OSX
setManifestid(1275893, "6494637690478994295", 958324793)