-- 1902490's Lua and Manifest Created by Morrenus
-- Aperture Desk Job
-- Created: September 28, 2025 at 22:45:34 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 4
-- Total DLCs: 0
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(1902490) -- Aperture Desk Job
-- MAIN APP DEPOTS
addappid(1902491, 1, "7b4bca0e4c7ec51479de7910bd8aabeaa3cd0fa7af14dc6520cf7f32579e8ef5") -- Depot 1902491
setManifestid(1902491, "8072925914291252462", 4277641148)
addappid(1902492, 1, "a1c9040f34b5c6df6d1dbeb93ba178609b71425dfcde1d4e26ff3cb4a5885497") -- Depot 1902492
setManifestid(1902492, "152863936826529847", 376963948)
addappid(1902493, 1, "0a7d2aef906f57aa620e70ca60ecbfa35dd1782932a542bfb51152b290b4334e") -- Depot 1902493
setManifestid(1902493, "4447956572694694967", 183823555)
-- SHARED DEPOTS (from other apps)
addappid(228988, 1, "1845444d5e2cfd0ae65ae4a8fedb6e2fbf776fcc5b913ab4ac461bc9a74f8358") -- VC 2019 Redist (Shared from App 228980)
setManifestid(228988, "6645201662696499616", 29212173)