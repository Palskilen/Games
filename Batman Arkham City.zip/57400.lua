-- 57400's Lua and Manifest Created by Morrenus
-- Batman: Arkham City™
-- Created: September 29, 2025 at 00:13:06 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 12
-- Total DLCs: 14

-- MAIN APPLICATION
addappid(57400) -- Batman: Arkham City™
-- MAIN APP DEPOTS
addappid(57401, 1, "8feb471e5e430cc44617e3d5d402a5e45ddc5a4da1ef2833a0f94231ece6dd6a") -- Batman2 Depot
setManifestid(57401, "2950732688474032267", 17669267679)
-- DLCS WITH DEDICATED DEPOTS
-- Batman Arkham City 1970s Batsuit (AppID: 200770)
addappid(200770)
addappid(200770, 1, "7a5f5475e857382fb8e5702a7f477640a652288bb0f7f155b50ed82873bc81b9") -- Batman Arkham City 1970s Batsuit - Batman Arkham City: 1970's Batsuit
setManifestid(200770, "314844212638126146", 46076324)
-- Batman Arkham City Year One Batman (AppID: 200780)
addappid(200780)
addappid(200780, 1, "39b08807eb79bd4183c1ae15eddea4fda6dbdb3e2211eb46feb5429d0c8d4938") -- Batman Arkham City Year One Batman - Batman Arkham City: Year One Batman
setManifestid(200780, "8380129807686186992", 47923822)
-- Batman Arkham City Animated Batman (AppID: 200790)
addappid(200790)
addappid(200790, 1, "8afd35ccd360b5f3f457353536a98ae8cc95e381e6616df0b151d80099453520") -- Batman Arkham City Animated Batman - Batman Arkham City: Animated Batman
setManifestid(200790, "7509277126840873257", 42424673)
-- Batman Arkham City Sinestro Corps Batman (AppID: 200800)
addappid(200800)
addappid(200800, 1, "0c17a4c25ca5c4e9040a81b4c96dcd1f503c16936c92ecc29c24c4e9dad0ad1a") -- Batman Arkham City Sinestro Corps Batman - Batman Arkham City: Sinestro Corps Batman
setManifestid(200800, "6157075979022260667", 39004206)
-- Batman Arkham City The Dark Knight Returns (AppID: 200810)
addappid(200810)
addappid(200810, 1, "43b6af5e50e2b91919a6344e0c55e4d75edd5fa2847fa9a213a4c4af899c1362") -- Batman Arkham City The Dark Knight Returns - Batman Arkham City: The Dark Knight Returns
setManifestid(200810, "3831188389279303808", 46853835)
-- Batman Arkham City Earth One Batman (AppID: 200820)
addappid(200820)
addappid(200820, 1, "49f507fc9eb9519bd71e64bdb384fc7b60dde132df9655f642d17946777394b1") -- Batman Arkham City Earth One Batman - Batman Arkham City: Earth One Batman
setManifestid(200820, "3925693454372272211", 48617075)
-- Batman Arkham City Batman Beyond Batman (AppID: 200830)
addappid(200830)
addappid(200830, 1, "fb466f40469c1135e920193f1e0842fff7300afe80852a7dca325d06d956dcb6") -- Batman Arkham City Batman Beyond Batman - Batman Arkham City: Batman Beyond Batman
setManifestid(200830, "1100313538582219372", 49146431)
-- Batman Arkham City The Jokers Carnival Challenge Map (AppID: 200840)
addappid(200840)
addappid(200840, 1, "b6e35849b2de327127475e82767dfabd05df9f8835811eeca4d0e3ad6b338fe9") -- Batman Arkham City The Jokers Carnival Challenge Map - Batman Arkham City: The Joker's Carnival Challenge Map
setManifestid(200840, "8814965749231064075", 80085120)
-- Batman Arkham City Iceberg Lounge (AppID: 200850)
addappid(200850)
addappid(200850, 1, "e4648d1078adebb56c7fd3f82c70122ef1e8e200a3cf16f50899923de1af0206") -- Batman Arkham City Iceberg Lounge - Batman Arkham City: Iceberg Lounge
setManifestid(200850, "4028464813765754845", 62602787)
-- Batman Arkham City Arkham City Skins Pack (AppID: 200860)
addappid(200860)
addappid(200860, 1, "fc8493faa2ba8c15fb55601acd81443e28a5c04f97c61da8bf2b8c7bb1ad8751") -- Batman Arkham City Arkham City Skins Pack - Batman Arkham City: Arkham City Skins Pack
setManifestid(200860, "172749713783947435", 209436688)
-- Batman Arkham City Challenge Map Pack (AppID: 200890)
addappid(200890)
addappid(200890, 1, "54bf07aa4c0d2d26e1c261f95f6034e3bd938b3aa38bbb5ca34423f7e38e86f2") -- Batman Arkham City Challenge Map Pack - Batman Arkham City: Challenge Map Pack
setManifestid(200890, "46508800505161212", 193683670)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(200870) -- Batman Arkham City Robin Bundle
addappid(200880) -- Batman Arkham City Nightwing Bundle
addappid(200891) -- Batman Arkham City Harley Quinn