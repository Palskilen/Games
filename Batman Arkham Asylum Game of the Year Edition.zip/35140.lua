-- 35140's Lua and Manifest Created by Morrenus
-- Batman: Arkham Asylum GOTY Edition
-- Created: September 29, 2025 at 00:12:53 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 12
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(35140) -- Batman: Arkham Asylum GOTY Edition
-- MAIN APP DEPOTS
addappid(35141, 1, "f108f5ba5d141ab8c93aa46f8e12693037a0485a896866c958451b685e52c979") -- batman_aa_goty_content
setManifestid(35141, "873843482869406112", 8471095333)
addappid(35142, 1, "09239b68f83e2fb836c7bb735e1b96a0121243a9f54346e43e1b07a2e22181eb") -- Batman Arkham Asylum GOTY French
setManifestid(35142, "4911371076158573761", 26)
addappid(35143, 1, "03b986768a588012bfb5fdaf3ad11ee4b33b4b408b31d08814594395d80277e9") -- Batman Arkham Asylum GOTY German
setManifestid(35143, "5744972823522856010", 26)
addappid(35144, 1, "f7e30e80f5483b2293302be3c8ea049375827e43459f1ae6aca38b25c0e9a3b9") -- Batman Arkham Asylum GOTY Italian
setManifestid(35144, "89354243401534757", 26)
addappid(35145, 1, "5e41b416397a0e7dd3880e84a2056b7d1629ec343e6cf1dd440f77b60e65760c") -- Batman Arkham Asylum GOTY Spanish
setManifestid(35145, "362455222359995561", 26)
addappid(35146, 1, "1c4be18237c9fb70b0a3119c9ea7a5a0f9c2c96c4c794b2b8076ee813d145aca") -- Batman: Arkham Asylum GOTY Edition Data
setManifestid(35146, "4235863132682389776", 9904956159)
addappid(35147, 1, "43851e08bc4211e287d7438b90d217c1af581fdfa70559853fb740e07a2a5643") -- Batman: Arkham Asylum GOTY Edition App
setManifestid(35147, "4513721724160477233", 147813872)
addappid(35148, 1, "77ba00a31ee00c85678bd665f48e806274e08e2e7d56956dc4a4abea803895b3") -- Batman: Arkham Asylum GOTY Edition French
setManifestid(35148, "5644989832991465893", 2)
addappid(35149, 1, "ef3207d6c0fbbee9dac9b6b80ebeecd26aed9bdb8ea8db954d91bafa3b77a537") -- Batman: Arkham Asylum GOTY Edition German
setManifestid(35149, "6473125455391125482", 2)
addappid(342720, 1, "f0d582036bf5422ef9b7bc8206606595462eb31d60dfba1db8a2a71f43489203") -- Batman: Arkham Asylum GOTY Edition Italian
setManifestid(342720, "711200135367581059", 2)
addappid(342721, 1, "c652b833d6129755643a0bb77e73670ac65f8f0844fe9850302f1169f5b369d4") -- Batman: Arkham Asylum GOTY Edition Spanish
setManifestid(342721, "2931604661506951695", 2)
addappid(342722, 1, "5ce07695ab96d37dc7d96f5a2005e62536476b716cd6cb9bf2ab53c0967e4fb6") -- Batman: Arkham Asylum GOTY Edition English
setManifestid(342722, "4439952150676537934", 2)