-- 502500's Lua and Manifest Created by Morrenus
-- ACE COMBAT™7: SKIES UNKNOWN
-- Created: September 28, 2025 at 21:25:51 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 29
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(502500) -- ACE COMBAT™7: SKIES UNKNOWN
-- MAIN APP DEPOTS
addappid(502501, 1, "4e4b9bdc3f7b06ab29a76821f3b5bce34934c44681a99dce451c0bb12ea9ff2d") -- GOJUN Content
setManifestid(502501, "788319397026631312", 65663762225)
-- SHARED DEPOTS (from other apps)
addappid(228987, 1, "cf0622b6dec67606fdc42e7afa5ede78cb33e38dfab82670c5ec7e1404e4984e") -- VC 2017 Redist (Shared from App 228980)
setManifestid(228987, "4302102680580581867", 29664201)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(868310) -- ACE COMBAT7 SKIES UNKNOWN - ADF-11F Raven Set
addappid(868311) -- ACE COMBAT7 SKIES UNKNOWN - ADF-01 FALKEN Set
addappid(868312) -- ACE COMBAT7 SKIES UNKNOWN - ADFX-01 Morgan Set
addappid(929100) -- ACE COMBAT7 SKIES UNKNOWN - Unexpected Visitor
addappid(929101) -- ACE COMBAT7 SKIES UNKNOWN - Anchorhead Raid
addappid(929102) -- ACE COMBAT7 SKIES UNKNOWN - Ten Million Relief Plan
addappid(929103) -- ACE COMBAT7 SKIES UNKNOWN - F-4E Phantom II  3 Skins
addappid(929104) -- ACE COMBAT7 SKIES UNKNOWN - 8 Popular Squadron Emblems
addappid(929105) -- ACE COMBAT7 SKIES UNKNOWN - Music Player Mode
addappid(929106) -- ACE COMBAT7 SKIES UNKNOWN - Season Pass
addappid(1421540) -- ACE COMBAT7 SKIES UNKNOWN  ASF-X Shinden II Set
addappid(1421550) -- ACE COMBAT7 SKIES UNKNOWN  XFA-27 Set
addappid(1421551) -- ACE COMBAT7 SKIES UNKNOWN  CFA-44 Nosferatu Set
addappid(1421552) -- ACE COMBAT7 SKIES UNKNOWN - 25th Anniversary Skin Set
addappid(1421553) -- ACE COMBAT7 SKIES UNKNOWN - 25th Anniversary Emblem Set
addappid(1454770) -- ACE COMBAT7 SKIES UNKNOWN - 25th Anniversary DLC - Original Aircraft Series  Set
addappid(1561360) -- ACE COMBAT7 SKIES UNKNOWN 25th Anniversary DLC - Experimental Aircraft Series Set
addappid(1561361) -- ACE COMBAT7 SKIES UNKNOWN - F-16XL Set
addappid(1561362) --  ACE COMBAT7 SKIES UNKNOWN - F-15 SMTD Set
addappid(1561363) -- ACE COMBAT7 SKIES UNKNOWN - FB-22 Strike Raptor Set
addappid(1561364) -- ACE COMBAT7 SKIES UNKNOWN - 25th Anniversary Skin Set II
addappid(1561365) -- ACE COMBAT7 SKIES UNKNOWN - 25th Anniversary Emblem Set II
addappid(1692460) -- ACE COMBAT7 SKIES UNKNOWN 25th Anniversary DLC - Cutting-Edge Aircraft Series Set
addappid(1692462) -- ACE COMBAT7 SKIES UNKNOWN - FA-18F Super Hornet Block III Set
addappid(1692463) -- ACE COMBAT7 SKIES UNKNOWN - F-2A -Super Kai- Set
addappid(1692464) -- ACE COMBAT7 SKIES UNKNOWN - MiG-35D Super Fulcrum Set
addappid(1692465) -- ACE COMBAT7 SKIES UNKNOWN - 25th Anniversary Skin Set III
addappid(1692466) -- ACE COMBAT7 SKIES UNKNOWN - 25th Anniversary Emblem Set III 
addappid(1966880) -- ACE COMBAT7 SKIES UNKNOWN - TOP GUN Maverick Aircraft Set -