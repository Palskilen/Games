-- 502820's Lua and Manifest Created by Morrenus
-- Batman™: Arkham VR
-- Created: September 29, 2025 at 00:14:33 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 0
-- Shared Depots: 2

-- MAIN APPLICATION
addappid(502820) -- Batman™: Arkham VR
-- MAIN APP DEPOTS
addappid(502821, 1, "44875eeeedbd724d166300e14b3986b6341b9fcad84c2bb04977513d83255eb2") -- Batman: Arkham VR Content
setManifestid(502821, "3182452647802925368", 8430609276)
-- SHARED DEPOTS (from other apps)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)