-- 306020's Lua and Manifest Created by Morrenus
-- Bloons TD5
-- Created: November 30, 2025 at 14:52:58 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 5
-- Total DLCs: 18
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(306020, 1, "96b38ecd1801155677084d644346a9eadad6b8abbc7dc2f17aeb2bcc0cda2ec4") -- Bloons TD5
-- MAIN APP DEPOTS
addappid(306022, 1, "af6c510d8e872e7e27afbd7c4326c200a1554a35edd96c37f8be3643a6abfc2f") -- BTD5 Win
setManifestid(306022, "5474703482974241093", 402511278)
addappid(306023, 1, "72b93511214ea34f78eb60c4015f585a1552a4ebc2e399138300e93afde703c7") -- BTD5 OSX
setManifestid(306023, "6152305758858558358", 282015398)
-- SHARED DEPOTS (from other apps)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228986, 1, "51dd3611d28621644730736f3bb1fd6b960053a45cd79123f2b9a80c9181dad5") -- VC 2015 Redist (Shared from App 228980)
setManifestid(228986, "8782296191957114623", 29759921)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(691480) -- Bloons TD 5 - Medieval Dart Monkey Skin
addappid(691490) -- Bloons TD 5 - Samurai Ninja Monkey Skin
addappid(691500) -- Bloons TD 5 - Mystical Apprentice Monkey Skin
addappid(691510) -- Bloons TD 5 - Military Bomb Tower Skin
addappid(692150) -- Bloons TD 5 - Top Gun Monkey Ace Skin
addappid(692151) -- Bloons TD 5 - Candy Banana Farm Skin
addappid(692152) -- Bloons TD 5 - Tribal Boomerang Thrower Skin
addappid(692153) -- Bloons TD 5 - Hunter Sniper Monkey Skin
addappid(820220) -- Bloons TD 5 - Fireworks Mortar Tower Skin
addappid(820230) -- Bloons TD 5 - Navy Monkey Buccaneer Skin
addappid(820231) -- Bloons TD 5 - Steampunk Monkey Sub Skin
addappid(820232) -- Bloons TD 5 - UFO Heli Pilot Skin
addappid(949780) -- Bloons TD 5 - Halloween Dart Monkey Skin
addappid(2191990) -- Bloons TD 5 - Classic Dart Monkey Skin
addappid(2191991) -- Bloons TD 5 - Classic Tack Tower Skin
addappid(2191992) -- Bloons TD 5 - Classic Bomb Tower Skin
addappid(2191993) -- Bloons TD 5 - Classic Ice Tower Skin
addappid(2191994) -- Bloons TD 5 - Classic Super Monkey Skin