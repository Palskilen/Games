-- 916440's Lua and Manifest Created by Morrenus
-- Anno 1800
-- Created: September 28, 2025 at 22:37:02 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 6
-- Total DLCs: 35

-- MAIN APPLICATION
addappid(916440) -- Anno 1800
-- MAIN APP DEPOTS
addappid(916441, 1, "fdf2da2bad8516bd58704e87cdd2101173aa1330d9328186184ff6445a945e19") -- Anno 1800 Content
setManifestid(916441, "6124783162666472131", 97163966911)
addappid(916442, 1, "eb8f0f30eafebbbaf8c5870c365708e8a973fd5d817e79d08db91170da90284b") -- Anno 1800 English
setManifestid(916442, "1322343137084862164", 1144616917)
addappid(916443, 1, "070c294380877e9c7d8f2daab4a07fe0b2194473c79502b71e66b11d5ec4bbf0") -- Anno 1800 German
setManifestid(916443, "2181072315111797237", 1193059467)
addappid(916444, 1, "5f6372b7a1ed235b555d05aa54ec7bea9f3d4b08906633514b058b5bd14f4e6c") -- Anno 1800 French
setManifestid(916444, "7565422157144661605", 1108767210)
addappid(916445, 1, "2bb378d0ec6043f34d63cbf2c37a06e9d61c9c197188638cdd24b6fccc0ccbbf") -- Anno 1800 Russian
setManifestid(916445, "2803529792524411023", 1058811838)
-- DLCS WITH DEDICATED DEPOTS
-- Anno 1800 - Deluxe Pack (AppID: 1066852)
addappid(1066852)
addtoken(1066852, "13854832133522835162")
addappid(916446, 1, "96ca058661170b58b95d8745bf9a352795ee003dfbf96c622825b88063eada12") -- Anno 1800 - Deluxe Pack - Anno 1800 Soundtrack & Artbook
setManifestid(916446, "5306902030699936255", 240444078)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(1066850) -- Anno 1800 - Season Pass
addtoken(1066850, "12111271149057402995")
addappid(1125790) -- Anno 1800 - Sunken Treasure
addappid(1125792) -- Anno 1800 - Botanica
addtoken(1125792, "15363863492004126802")
addappid(1125794) -- Anno 1800 - The Passage
addtoken(1125794, "10348292758142420166")
addappid(1210040) -- Anno 1800  Holiday pack
addtoken(1210040, "16759723954527412761")
addappid(1247680) -- Anno 1800 - Seat of Power
addtoken(1247680, "3197839846494379136")
addappid(1247710) -- Anno 1800 - Year 2 Pass
addtoken(1247710, "8973042785894684627")
addappid(1314950) -- Anno 1800 - Bright Harvest
addtoken(1314950, "14151021687858726039")
addappid(1383240) -- Anno 1800 - Amusements Pack
addtoken(1383240, "6035183030212088646")
addappid(1442810) -- Anno 1800 - Land of Lions
addappid(1465650) -- Anno 1800 - City Lights Pack
addappid(1530880) -- Anno 1800 - Year 3 Pass
addtoken(1530880, "10032381193074420280")
addappid(1530882) -- Anno 1800 - Docklands
addappid(1626970) -- Anno 1800 - Tourist Season
addtoken(1626970, "14431331289985871920")
addappid(1626972) -- Anno 1800 - Vehicle Liveries
addtoken(1626972, "7686359769432141679")
addappid(1704680) -- Anno 1800 - The High Life
addappid(1704690) -- Anno 1800 - Pedestrian Zone Pack
addtoken(1704690, "4766422470377779440")
addappid(1803742) -- Anno 1800 - Vibrant Cities Pack
addappid(1881100) -- Anno 1800 - Seasonal Decorations Pack
addappid(1933240) -- Anno 1800 - Year 4 Season Pass
addappid(1933242) -- Anno 1800 - Cosmetic Pack Bundle
addappid(1933244) -- Anno 1800 - Seeds of Change
addappid(2055760) -- Anno 1800 - Industrial Zone Pack
addappid(2074410) -- Anno 1800 - Empire of the Skies Pack
addappid(2222640) -- Anno 1800  New World Rising Pack
addappid(2222650) -- Anno 1800 - Old Town Pack
addappid(2277980) -- Anno 1800  Dragon Garden Pack
addappid(2400950) -- Anno 1800 - Fiesta Pack
addappid(2504950) -- Anno 1800 - National Park Pack
addappid(2622020) -- Anno 1800 - Cosmetic Bundle 2
addappid(2622040) -- Anno 1800 - Eldritch Pack
addappid(2830580) -- Anno 1800 - Steampunk Pack
addappid(3113620) -- Anno 1800 - Pirate Cove Pack
addappid(3256930) -- Anno 1800 - End of an Era Pack