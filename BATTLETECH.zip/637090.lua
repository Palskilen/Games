-- 637090's Lua and Manifest Created by Morrenus
-- BATTLETECH
-- Created: November 29, 2025 at 08:02:33 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 6
-- Total DLCs: 6
-- Shared Depots: 1

-- MAIN APPLICATION
addappid(637090) -- BATTLETECH
-- MAIN APP DEPOTS
addappid(637092, 1, "72e809a00199a64ddb64c1717150de9181f02271843a6ea5311727ef05dc121c") -- BattleTech (Windows)
setManifestid(637092, "3571434299329528407", 36058598614)
addappid(637093, 1, "5f0d196f62d8d69788898d9edbed872c3b429190cda48731c2577a728ce32731") -- BattleTech (OSX)
setManifestid(637093, "8187034275620793063", 35712170759)
addappid(637094, 1, "123cab6b69f00e7573e00655bc5149ca1e274d68b9c23523cddafc512250f1cb") -- BattleTech (Linux)
setManifestid(637094, "3849333830107924190", 35696335784)
-- SHARED DEPOTS (from other apps)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)
-- DLCS WITH DEDICATED DEPOTS
-- BATTLETECH - Shadow Hawk Pack (AppID: 799751)
addappid(799751)
addappid(799751, 1, "f07fbc91a9f25211123f652288f7db0fbe95d46a7eeeca2895ec26a1f3143b8f") -- BATTLETECH - Shadow Hawk Pack - BATTLETECH - Shadowhawk Pack (799751) Depot
setManifestid(799751, "669435259793615635", 15990961)
-- BATTLETECH Digital Deluxe Content (AppID: 799790)
addappid(799790)
addappid(799790, 1, "27dd0fce73456d746fe86022a47bc1c659327ab510c97dbc03c8522008926f7e") -- BATTLETECH Digital Deluxe Content - BATTLETECH Digital Deluxe Content (799790) Depot
setManifestid(799790, "2702170670973061830", 1077304372)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(799750) -- BATTLETECH Season Pass
addappid(911930) -- BATTLETECH Flashpoint
addappid(1047180) -- BATTLETECH Urban Warfare
addappid(1151170) -- BATTLETECH Heavy Metal