-- 107410's Lua and Manifest Created by Morrenus
-- Arma 3
-- Created: December 16, 2025 at 08:53:09 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 49
-- Total DLCs: 23
-- Shared Depots: 7

-- MAIN APPLICATION
addappid(107410, 1, "41ff2badbff9351171ac6dd5b518595760f066656bcc157cdd77aa28046e176e") -- Arma 3
-- MAIN APP DEPOTS
addappid(249504, 1, "7a5c9a04f58f3f86cbdef4e9f2817629d08bbf84a1f4321e13f917f6e92887d6") -- Arma 3 FW Depot
setManifestid(249504, "1015968845214793196", 15506687470)
addappid(107411, 1, "833b10a4156402ff5a874c5fe740af6294d055f92fc25c69607b3351ffbfe679") -- ARMA 3 Content=
setManifestid(107411, "8681622824861525347", 43448649848)
addappid(249505, 1, "f77130c5d488aced7c009e872beb263ef9a845463aed4372c5968c310cc6565a") -- Arma 3 Port - Shared Content
setManifestid(249505, "4710415249300085255", 43130118359)
addappid(107418, 1, "b20b8b302fd775dd5f510f4c6d92303e5e9e91a5c1dd63b49d5fba5c73a16e15") -- Arma 3 Russian langs=
setManifestid(107418, "4453606239766500928", 71881421)
addappid(107413, 1, "44faf57ebfee712ae9316d3f7ec77e3a763190dc8325e63cc8aa23235718f798") -- Arma 3 Digital Langs
setManifestid(107413, "4366971045032605238", 389008753)
addappid(107415, 1, "74e3e7e31e761aa6fa007fc703408e88a980512d3bc0f737c2b724bcef1ccc38") -- Arma 3 Korean langs
setManifestid(107415, "399082926725356362", 70399518)
addappid(249506, 1, "720c4414485a1bd6aad38fb825f7455fc6f41d61176a6eab369d339a64601ff5") -- Arma 3 Port - Language Content
setManifestid(249506, "3528280476930921194", 61934455)
addappid(107420, 1, "721d759ad3199299425a057d3075e0bf1078ea624d65faae71bd11254617a966") -- Arma 3 English
setManifestid(107420, "7053381975926971498", 8323105)
addappid(107421, 1, "965c797f05169d0a632cea851fab1d418d19ba8557a54af8f32667658782dca1") -- Arma 3 French
setManifestid(107421, "2479538286611674481", 7926395)
addappid(107422, 1, "5dc537b4337aaafa4d100493e59e8a7ee84cbcedb16777622685a2047d91a306") -- Arma 3 German
setManifestid(107422, "694831486858131928", 7927043)
addappid(107423, 1, "4a4d56da6c332cd0be710e0e7b3117dab1f73ed51810d800a7e747011ab69a85") -- Arma 3 Italian
setManifestid(107423, "5294990231226172562", 7923976)
addappid(107424, 1, "f9348a2559cf47ded3a0f49e4dcb54281587c1f5725499091856cf1866c49fba") -- Arma 3 Spanish
setManifestid(107424, "3395489159717928684", 7929667)
addappid(107425, 1, "398f6319a28f9570857894591a9c2e2168669f521529f30bc42d00b73b9a89dc") -- Arma 3 Czech
setManifestid(107425, "4906889931917921096", 8027541)
addappid(107426, 1, "6c45afa220059d2deb0b16d7ee972cc58e158f8e55b885bf09296867ba76e3ab") -- Arma 3 Russian
setManifestid(107426, "4684404531445583131", 7958426)
addappid(107427, 1, "2e127da445a329f971cb2da6f95a042f20ea9b14829fb74179f34841e710a815") -- Arma 3 Polish
setManifestid(107427, "8406091474147147301", 7931130)
addappid(107428, 1, "055d57fcc12ff12b49a329f177eba80af24ec36b377ba03148e2d9d4172effa7") -- Arma 3 Portuguese-Brazil
setManifestid(107428, "5514411074045516159", 7928022)
addappid(107429, 1, "5f3b60be0c035cec10f8fb64490071b14f4a6ca0375f7495e2b2dab864f8904c") -- Arma 3 Korean
setManifestid(107429, "9165345853969700754", 8654136)
addappid(249501, 1, "37f6a5a690ef6ecccf4eb4197d2256b611bf80cc95338ff552f8f09c100086a5") -- Arma 3 Japanese
setManifestid(249501, "8720942636409428537", 8774402)
addappid(249510, 1, "af7b2fba5a503e59c847039be22b27bde7385d837b8a4211cb46d77e70715022") -- Arma 3 Simplified Chinese
setManifestid(249510, "6620680010375519103", 5763293)
addappid(249511, 1, "cfd49c5a7dd4d67a3cebfaa501b735cef12ca4dbca4e21e5fe5df3984a4fe7c3") -- Arma 3 Traditional Chinese
setManifestid(249511, "2843568687622074286", 5897616)
addappid(249512, 1, "e88d176e948e932b3f6682bc73e9836ee83bfbdb65ca649efdbc49e833c1cdc5") -- Arma 3 Turkish
setManifestid(249512, "4734283135240260657", 4115665)
addappid(249860, 1, "b1d6aa1d14f16b1f383aec21c0931c12832a42239eb026f5afaa6d8e970de449") -- Arma 3 Soundtrack (249860) Depot
setManifestid(249860, "7431003676632113359", 2236978896)
addappid(249502, 1, "277ba94f2fa9a7f293ee635051aecd51bf5b7580fbde96927600d9f9f7fdf903") -- Depot 249502
setManifestid(249502, "2855841879143950386", 54392226)
addappid(249508, 1, "f384303deb8d08f3dcadcf71d670a0bae23e6e46f72b2e9426152a725c48a40b") -- Arma 3 Port - Mac Bin
setManifestid(249508, "5458918759913472458", 350245836)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228984, 1, "df7df98d3134f5e0009d5ebcaaf3bbb91ea2f7cbad81a37a9d16bc1835f57068") -- VC 2012 Redist (Shared from App 228980)
setManifestid(228984, "2547553897526095397", 13742505)
addappid(228985, 1, "21a2f639584d9bd462c5c4b3e10f881cba8a17ae674c830c4f083551cd356e9c") -- VC 2013 Redist (Shared from App 228980)
setManifestid(228985, "3966345552745568756", 13699237)
addappid(228989, 1, "ad69276eb476cf06c40312df7376d63deac0c838b9a2767005be8bb306ffb853") -- VC 2022 Redist (Shared from App 228980)
setManifestid(228989, "3514306556860204959", 39590283)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229004, 1, "56ebe05d052f59ad2e9b101102de603dca17402a9bb2ef0015962c6b3275a2d0") -- .NET 4.5.2 Redist (Shared from App 228980)
setManifestid(229004, "5220958916987797232", 70000464)
addappid(229006, 1, "9bc3e05ce55153e5c315cb18024602ca15958a7be03adc5ffbe53b00a8524416") -- .NET 4.7 Redist (Shared from App 228980)
setManifestid(229006, "1784011429307107530", 83944258)
-- DLCS WITH DEDICATED DEPOTS
-- Arma 3 Maps (AppID: 249861)
addappid(249861)
addtoken(249861, "6943354596756530945")
addappid(249861, 1, "352a937f53f6ec85eae8f2755e3b1609dca20c54af30799cd956e6f7d046c932") -- Arma 3 Maps - Arma 3 Maps (249861) Depot
setManifestid(249861, "4518665814873472898", 416957861)
-- Arma 3 Tactical Guide (AppID: 249862)
addappid(249862)
addtoken(249862, "16685319281903082284")
addappid(249862, 1, "8e31c7702caf35ce3aaedd6b0e2033ca5465b072c4de869482f8010f4d4b3117") -- Arma 3 Tactical Guide - Arma 3 Tactical Guide (249862) Depot
setManifestid(249862, "2738283997064954949", 75902607)
-- Arma 3 Apex (AppID: 395180)
addappid(395180)
addappid(395180, 1, "96c966f67619cb8112c41edd7b20dc6ae55e1fa5fd6de3b7e503e8951c6e43ef") -- Arma 3 Apex - Arma 3 Expansion (395180) Depot
setManifestid(395180, "8426651345227339980", 6126)
addappid(249509, 1, "eabd6887679e6f371df7c224fbebb6387e6be162c349c64d943a3cfaa09e4639") -- Arma 3 Apex - Arma 3 Port - Apex Expansion
setManifestid(249509, "4555863940473377516", 0)
-- Arma 3 Contact (AppID: 1021790)
addappid(1021790)
addappid(1021790, 1, "2a1a84bef4bca331a78e022e133ca531af3062be29de09bd05934c9ce49e733f") -- Arma 3 Contact - Arma 3 Contact (1021790) Depot
setManifestid(1021790, "968105706013589959", 1270902055)
-- Arma 3 Creator DLC Global Mobilization - Cold War Germany (AppID: 1042220)
addappid(1042220)
addappid(1042220, 1, "d2d2b4ba7701e9067b5d6b00d91c57839c42a7032a985a69c57612b16ce61e21") -- Arma 3 Creator DLC Global Mobilization - Cold War Germany - Arma 3 Creator DLC - GM (1042220) Depot
setManifestid(1042220, "5561821618542621196", 38351201034)
addappid(1042221, 1, "285b4b9b2bd5ad724cdf3997240446475ac631a84ff726879ed717cf5ed635b9") -- Arma 3 Creator DLC Global Mobilization - Cold War Germany - Arma 3 Creator DLC: Global Mobilization - Cold War Germany
setManifestid(1042221, "2053062434401462647", 38351201034)
-- Arma 3 Creator DLC Spearhead 1944 (AppID: 1175380)
addappid(1175380)
addappid(1175380, 1, "1527e79ee970b83c9e29530acf0ad8c557fec87abcd7cdfafe10a9163ccc6896") -- Arma 3 Creator DLC Spearhead 1944 - Arma 3 - Prague Content 2 (1175380) Depot
setManifestid(1175380, "8749914837138314128", 31183452901)
addappid(1175381, 1, "6173300769cbd0edac4a68b33bf2333f3bc062c9b5b1da31f9c79549ae8e947e") -- Arma 3 Creator DLC Spearhead 1944 - Depot 1175381
setManifestid(1175381, "6576197082193427041", 31179624693)
-- Arma 3 Creator DLC S.O.G. Prairie Fire (AppID: 1227700)
addappid(1227700)
addappid(1227700, 1, "62492374d9e872dec77870f24170bb85cc1b28a1d792c8f081be2d5d3d167951") -- Arma 3 Creator DLC S.O.G. Prairie Fire - Arma 3 Creator DLC - SOGPF
setManifestid(1227700, "1889876263343541672", 38376191891)
addappid(1227701, 1, "70adde1421b521bb699fb2344e414ae08c97c56ea1a22342359778f40465302f") -- Arma 3 Creator DLC S.O.G. Prairie Fire - Arma 3 Creator DLC: S.O.G. Prairie Fire
setManifestid(1227701, "8778927882579535691", 38372517443)
-- Arma 3 Creator DLC CSLA Iron Curtain (AppID: 1294440)
addappid(1294440)
addappid(1294440, 1, "5b1e01c821d9d3707104d4faf25d64faac508a1304a8324f048e56566bb9821f") -- Arma 3 Creator DLC CSLA Iron Curtain - Arma 3 Creator DLC - CSLA
setManifestid(1294440, "8320117063324338394", 10479842211)
addappid(1294441, 1, "c2c39942b00fd547c6e3613a863ad9cb60eeb74e1208742302b4ba06309f7cfe") -- Arma 3 Creator DLC CSLA Iron Curtain - Arma 3 Creator DLC: CSLA Iron Curtain
setManifestid(1294441, "5407594059006667059", 10479842211)
-- Arma 3 Creator DLC Western Sahara (AppID: 1681170)
addappid(1681170)
addappid(1681170, 1, "89aa19de49b63e33c462859290ffc3e0a36b3168627208399bf4b8d1f160d8e3") -- Arma 3 Creator DLC Western Sahara - Arma 3 Creator DLC - WSahara
setManifestid(1681170, "3642395047610510906", 5301846999)
addappid(1681171, 1, "2b42cb143feee60349f0ddd52e0f275210a36b13db67378295d48e24ace805e0") -- Arma 3 Creator DLC Western Sahara - Arma 3 Creator DLC: Western Sahara
setManifestid(1681171, "738528337327303663", 5301846999)
-- Arma 3 Creator DLC Reaction Forces (AppID: 2647760)
addappid(2647760)
addappid(2647760, 1, "ea7053053da76cf6d68b4561d05eeba1736c31409b4e4e67afd56fff5533add1") -- Arma 3 Creator DLC Reaction Forces - Depot 2647760
setManifestid(2647760, "8773700064943194686", 4315226953)
addappid(2647761, 1, "d3823ed85d445668a83045544c6c20c0aae5a6e98a99d06fe56dc6ceb3474f99") -- Arma 3 Creator DLC Reaction Forces - Depot 2647761
setManifestid(2647761, "2576413575760136050", 4315226953)
-- Arma 3 Creator DLC Expeditionary Forces (AppID: 2647830)
addappid(2647830)
addappid(2647830, 1, "e5e2d7d83696d653ec6a4893b702afadf9978113d4c0f565d16a53fa04b3289a") -- Arma 3 Creator DLC Expeditionary Forces - Depot 2647830
setManifestid(2647830, "5948648344828699487", 3564160077)
-- DLCS WITHOUT DEDICATED DEPOTS
addappid(275700) -- Arma 3 Zeus
addappid(288520) -- Arma 3 Karts
addappid(304380) -- Arma 3 Helicopters
addappid(304400) -- Arma 3 DLC Bundle 1
addtoken(304400, "2907071240555921015")
addappid(332350) -- Arma 3 Marksmen
addappid(571710) -- Arma 3 Laws of War
addappid(601670) -- Arma 3 Jets
addappid(612480) -- Arma 3 DLC Bundle 2
addappid(639600) -- Arma 3 Malden
addappid(744950) -- Arma 3 Tac-Ops Mission Pack
addappid(798390) -- Arma 3 Tanks
addappid(1325500) -- Arma 3 Art of War