-- 688420's Lua and Manifest Created by Morrenus
-- Bad North
-- Created: September 28, 2025 at 23:57:30 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 3
-- Total DLCs: 1

-- MAIN APPLICATION
addappid(688420) -- Bad North
-- MAIN APP DEPOTS
addappid(688421, 1, "525079f6b1d23bbcaace38e134d75021bc71b75853a8e538a802326ce95897cc") -- Bad North Windows x86
setManifestid(688421, "8800218574177501794", 229444423)
addappid(688423, 1, "216ca3b6d87e9cc1152b065fa3f7178f0f68a2710e55a026f12a235a04e8d7b2") -- Bad North OSX
setManifestid(688423, "6768053692751736512", 297717593)
-- DLCS WITH DEDICATED DEPOTS
-- Bad North - Deluxe Edition Content (AppID: 970060)
addappid(970060)
addappid(970060, 1, "d34dd4efea15ff2655d034a2d54792fe2daa21459e7e709102fc3f0a08003d58") -- Bad North - Deluxe Edition Content - Bad North - Deluxe Edition Content (970060) Depot
setManifestid(970060, "802016381599387244", 157913951)