-- 228400's Lua and Manifest Created by Morrenus
-- ACE COMBAT™ ASSAULT HORIZON Enhanced Edition
-- Created: September 28, 2025 at 21:26:00 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(228400) -- ACE COMBAT™ ASSAULT HORIZON Enhanced Edition
-- MAIN APP DEPOTS
addappid(228401, 1, "89ab00dec01ed2e290274bedeaa8ea1cbcc92e1279d83e70a589aa734e90acfe") -- Ace Combat Assault Horizon Content
setManifestid(228401, "8118125105387010428", 12518299948)