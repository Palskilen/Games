-- 269490's Lua and Manifest Created by Morrenus
-- Bardbarian
-- Created: September 29, 2025 at 00:09:04 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 2
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(269490) -- Bardbarian
-- MAIN APP DEPOTS
addappid(269491, 1, "f3073a5bd045c45404a138e6cc430b043c10eea845657c3103f26976c52087f1") -- Bardbarian - Windows
setManifestid(269491, "3565123993617164113", 156612485)
addappid(269492, 1, "b82a51c7405544e34f7a198133431c1b3896c04f331fdbad5a3e7dbe20be0105") -- Bardbarian - OSX
setManifestid(269492, "4592287833300142763", 299139562)