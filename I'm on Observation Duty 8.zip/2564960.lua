-- 2564960's Lua and Manifest Created by Morrenus
-- I'm on Observation Duty 8
-- Created: December 07, 2025 at 12:54:39 EST
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 1
-- Total DLCs: 0

-- MAIN APPLICATION
addappid(2564960) -- I'm on Observation Duty 8
-- MAIN APP DEPOTS
addappid(2564961, 1, "8619ed1f833ac61628161a34d05b81a83246600139a636ce027f3b5144b68543") -- Depot 2564961
setManifestid(2564961, "3706041139238830408", 1869567385)