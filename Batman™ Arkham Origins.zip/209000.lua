-- 209000's Lua and Manifest Created by Morrenus
-- Batman™: Arkham Origins
-- Created: September 29, 2025 at 00:14:21 EDT
-- Website: https://manifest.morrenus.xyz/
-- Total Depots: 25
-- Total DLCs: 12
-- Shared Depots: 3

-- MAIN APPLICATION
addappid(209000) -- Batman™: Arkham Origins
-- MAIN APP DEPOTS
addappid(209001, 1, "f5c100e9d6d4f1a524c3704ff3ef0e14933ca21f52c57fb607302527856d99ea") -- Ozzy Content
setManifestid(209001, "3461941926504860294", 19593363918)
addappid(209004, 1, "a02b22c7093dbc7c27960996cbe5b8d7e84d3249e0fb37614c803468ad87b989") -- Batman™: Arkham Origins German
setManifestid(209004, "6962761681899419745", 897070203)
addappid(209002, 1, "bfa7a84d592cab2693fe595a5f60612759a409377e68b01dff493425fc710c8f") -- Batman™: Arkham Origins Spanish
setManifestid(209002, "5279375398140027418", 1812289581)
addappid(209003, 1, "a77395939294ede504549b276cf392f33229c12cf25a92640d658904b740594d") -- Batman™: Arkham Origins French
setManifestid(209003, "6072903106311597909", 854107195)
addappid(209005, 1, "e0bf4517c3964dac1250280f7d11e70cf2789347ae475200ed8f3e8766bfa4b9") -- Batman™: Arkham Origins Italian
setManifestid(209005, "8862212808483926542", 879767100)
addappid(209006, 1, "ac849826385f5ab7fbcebe89dfe2765bb2e42f877d59293814f3320e76a6199d") -- Batman™: Arkham Origins Portuguese-Brazil
setManifestid(209006, "5317034876422030410", 861187547)
addappid(237611, 1, "f43e366258baf0e175af8b1a3c72dae9451616dc8422bc0b0bffb47f5ef72032") -- DLC_SkinsNew52
setManifestid(237611, "104515676782256082", 359)
addappid(237612, 1, "9348a1875140552d806f6bd09e956f54cf0ddcb897f975231d894d5c5b494b11") -- DLC_SkinsInjustice
setManifestid(237612, "85033816772681601", 577)
addappid(237614, 1, "6fca7e127f49b34286c449384862aad750a20e894b27d34295a69d831d0b1a62") -- DLC_SkinsEarth2DK
setManifestid(237614, "263483447526310295", 373)
addappid(250960, 1, "7ea3aba98e7d2484dc3df0a93b78902df72e82793e03a54826a4c0e122212f51") -- Batman: Arkham Origins - Knightfall (250960) Depot
setManifestid(250960, "1142759452489079425", 6451774376)
-- SHARED DEPOTS (from other apps)
addappid(228983, 1, "77c8e812cd79e67e2d376721253ebb07e06b3646f05671c6c9517b27be14734b") -- VC 2010 Redist (Shared from App 228980)
setManifestid(228983, "8124929965194586177", 19265607)
addappid(228990, 1, "44d8c45ce229a11c4f231a3d2a350eaf80b0d69a8af938ec7ccca720f694b0e8") -- DirectX Jun 2010 Redist (Shared from App 228980)
setManifestid(228990, "1829726630299308803", 102931551)
addappid(229003, 1, "8e0ded6e1d9481eb286217322054ce7b0b8243daae770f31a30667752b1a3c63") -- .NET 4.0 Client Profile Redist (Shared from App 228980)
setManifestid(229003, "8740933542064151477", 43001447)
-- DLCS WITH DEDICATED DEPOTS
-- Batman Arkham Origins - Batman Legends Skins Pack (AppID: 237613)
addappid(237613)
addtoken(237613, "10414385122213275628")
addappid(237613, 1, "14824687eac8cafa76c06faf6dd87bd8120b058514c5732eb2446fb389de3cb9") -- Batman Arkham Origins - Batman Legends Skins Pack - DLC_SkinsWalmart
setManifestid(237613, "59544344938750174", 1082)
-- Batman Arkham Origins - Classic Tim Drake Robin (AppID: 237615)
addappid(237615)
addtoken(237615, "11167033899252634792")
addappid(237615, 1, "aeb4adf888d0b5bcbee2974c5b8d3b5168b9c6a966e90b9b87f32b9a0781475d") -- Batman Arkham Origins - Classic Tim Drake Robin - Batman: Arkham Origins - Classic Tim Drake Robin (237615) Depot
setManifestid(237615, "42058695844308960", 96)
-- Batman Arkham Origins - Jokers Vandal - Online Vanity Pack (AppID: 237616)
addappid(237616)
addtoken(237616, "9992533234782232139")
addappid(237616, 1, "510adce639c375a38e5a15dcf4167530fbe254156255f942ce2c6383370797cc") -- Batman Arkham Origins - Jokers Vandal - Online Vanity Pack - Batman: Arkham Origins - Joker's Vandal - Online Vanity Pack (237616) Depot
setManifestid(237616, "86300889472213919", 140)
-- Batman Arkham Origins - Banes Forces - Online Vanity Pack (AppID: 237617)
addappid(237617)
addtoken(237617, "2232863901432042557")
addappid(237617, 1, "7eebb41ca166843c438b20dfbb7a8e9e3118776ccac673418393a060f3baa6f8") -- Batman Arkham Origins - Banes Forces - Online Vanity Pack - Batman: Arkham Origins - Bane's Special Forces - Online Vanity Pack (237617) Depot
setManifestid(237617, "47616188141389102", 139)
-- Batman Arkham Origins - Black Mask Challenge Pack (AppID: 237618)
addappid(237618)
addtoken(237618, "5183929771147284240")
addappid(237618, 1, "9f7bc073e0c50f4a9b20811ae5abea8f9ae98cf4533d79a9edc3423ff96d1de4") -- Batman Arkham Origins - Black Mask Challenge Pack - DLC_Blackmask
setManifestid(237618, "238727171855921815", 1774)
-- Batman Arkham Origins - Initiation (AppID: 237619)
addappid(237619)
addappid(237619, 1, "9e975f440061a632e2632cbab6381d062a0377697f9cd8b5b4baae0561781306") -- Batman Arkham Origins - Initiation - DLC_NinjaBruce
setManifestid(237619, "2968141500099658504", 6614620042)
-- Batman Arkham Origins - New Millennium Skins Pack (AppID: 237620)
addappid(237620)
addappid(237620, 1, "984bd32ad0fedd1bd5ba00eecb5581ef6bdb0de49dfc802bf3c85ebb776a6965") -- Batman Arkham Origins - New Millennium Skins Pack - DLC_SkinsOrigins1
setManifestid(237620, "291659265756130075", 2145)
-- Batman Arkham Origins - Infinite Earths Skins Pack (AppID: 237621)
addappid(237621)
addappid(237621, 1, "dbe0682e42186c4645b17cbef630152fcd945bf8db52af15a9e698f179203f9b") -- Batman Arkham Origins - Infinite Earths Skins Pack - DLC_SkinsOrigins2
setManifestid(237621, "193572760426704607", 1597)
-- Batman Arkham Origins -  Online Supply Drop 1 (AppID: 237622)
addappid(237622)
addappid(237622, 1, "ff61aa614ba3ff2b3a25de5762d8114e7afb7a2bf679730dfd3c4b95f34f7e95") -- Batman Arkham Origins -  Online Supply Drop 1 - Batman: Arkham Origins - Invisible Predator Online - DLC Pack 1 (237622) Depot
setManifestid(237622, "447688492637553775", 261)
-- Batman Arkham Origins - Online Supply Drop 2 (AppID: 237623)
addappid(237623)
addappid(237623, 1, "3ea5c90b5c11e18fb70c151909ba805022d3765b2470342e70c4d2ff9a65c03b") -- Batman Arkham Origins - Online Supply Drop 2 - Batman: Arkham Origins - Invisible Predator Online - DLC Pack 2 (237623) Depot
setManifestid(237623, "164024816323774951", 261)
-- Batman Arkham Origins - Season Pass (AppID: 257070)
addappid(257070)
addtoken(257070, "9474245672847270760")
addappid(257070, 1, "90d24fd39def59cc38c2b91ee308ec8a53e01970f72a6942499d7018bf253a96") -- Batman Arkham Origins - Season Pass - Batman: Arkham Origins - Season Pass Exclusive Skin Pack (257070) Depot
setManifestid(257070, "386829247995520577", 655)
-- Batman Arkham Origins - Cold, Cold Heart (AppID: 277830)
addappid(277830)
addappid(277830, 1, "6c15ae569ddecfe0f84c2fa337cc7483e124646a7c616bac6ee548ce6f6a8375") -- Batman Arkham Origins - Cold, Cold Heart - Batman Arkham Origins Mr Freeze DLC (277830) Depot
setManifestid(277830, "5403156598974731213", 2851234616)